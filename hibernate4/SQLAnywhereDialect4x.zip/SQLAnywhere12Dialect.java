/**
 * SQL Dialect for SAP Sybase SQL Anywhere 12 with ANSI Isolation
 * for the Hibernate 4.x distribution
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 * 
 * Support: http://sqlanywhere-forum.sybase.com/
 *          http://www.sap.com/services-and-support/
 *
 */

package org.hibernate.dialect;

import org.hibernate.cfg.Environment;
import org.hibernate.dialect.function.StandardSQLFunction;
import org.hibernate.dialect.function.VarArgsSQLFunction;
import org.hibernate.type.StandardBasicTypes;

/**
 * @author 		SAP AG or an SAP affiliate company
 * @version 	4.0
 * @since			2013-01-22
 */
public class SQLAnywhere12Dialect extends SQLAnywhere11Dialect {

  /**
   * Constructor to create a SQL Anywhere 12 SQL Dialect
   *
   * Uses standard ANSI Isolation Levels
   */
	public SQLAnywhere12Dialect(){
		super();
		if (SQLAnywhere12Dialect.class.isInstance(this)) {
			registerSA12Keywords();
			registerSA12Functions();
		}
	}

  /**
   * Register SQL Anywhere 12 specific SQL keywords
   *
   * Note that this function may need to be changed
   * if 'limit' is registered as a keyword, using 'reserved_keywords'
   *
   * See the SQLAnywhereDialect README for more details
   */
	private void registerSA12Keywords(){
		//registerKeyword( "limit" );
		
		registerKeyword( "merge" );
		registerKeyword( "openstring" );
		registerKeyword( "openxml" );
		registerKeyword( "treat" );
	}

  /**
   * Register SQL Anywhere 12 specific SQL system functions
   */
	private void registerSA12Functions(){
		// SA11 functions
		registerFunction( "regex_substr", new VarArgsSQLFunction( StandardBasicTypes.STRING, "regex_substr(",",",")" ) );
		registerFunction( "read_client_file", new StandardSQLFunction("read_client_file", StandardBasicTypes.BLOB) );
		registerFunction( "write_client_file", new VarArgsSQLFunction( StandardBasicTypes.INTEGER, "write_client_file(",",",")" ) );
		
		// SA12 functions
		registerFunction( "http_response_header", new StandardSQLFunction("http_response_header", StandardBasicTypes.STRING) );
		registerFunction( "next_http_response_header", new StandardSQLFunction("next_http_response_header", StandardBasicTypes.STRING) );
		registerFunction( "isencrypted", new VarArgsSQLFunction( StandardBasicTypes.STRING, "isencrypted(",",",")" ) );
	}

  /**
   * Hibernate Framework indicator that SA supports Sequences
   */
	public boolean supportsSequences() {
		return true;
	}

  /**
   * Framework indicator that SA supports pooled sequences
   * ("Oracle-style sequences")
   */
	public boolean supportsPooledSequences() {
		return true;
	}

  /**
   * Get the SQL query string to return a list of sequences
   */
	public String getQuerySequencesString() {
		return "SELECT SEQUENCE_NAME FROM SYS.SYSSEQUENCE";
	}

  /**
   * Get the SQL query string to SELECT the next sequence value
   *
   * @param sequenceName  The sequence to get the next value from
   * @return              The SQL string
   */
	public String getSequenceNextValString(String sequenceName) {
		return "SELECT " + getSelectSequenceNextValString(sequenceName) + " FROM SYS.DUMMY";
	}

  /**
   * Get the SQL string that signifies the current sequence value
   *
   * @param sequenceName  The sequence to get the next value from
   * @return              The SQL string
   */
	public String getSelectSequenceNextValString(String sequenceName) {
		return sequenceName + ".NEXTVAL";
	}

  /**
   * Get the set of SQL strings to create a sequence
   *
   * Uses default sequence options (START WITH 1 INCREMENT BY 1)
   *
   * @param sequenceName  The sequence to generate SQL strings for
   * @return              The set of SQL strings
   */
	public String[] getCreateSequenceStrings(String sequenceName) {
		String[] sequences = { getCreateSequenceString(sequenceName) };
		return sequences;
	}

  /**
   * Get the set of SQL strings to create a sequence
   *
   * Uses non-default sequence options for intial values
   *
   * @param sequenceName  The sequence to generate SQL strings for
   * @param initialValue  The initial sequence starting value
   * @param incrementSize The sequence increment step size
   * @return              The set of SQL strings
   */
	public String[] getCreateSequenceStrings(String sequenceName,
			int initialValue,
			int incrementSize) {
		String[] sequences = { getCreateSequenceString(sequenceName, initialValue, incrementSize) };
		return sequences;
	}

  /**
   * Get the set of SQL strings to drop a sequence
   *
   * @param sequenceName  The sequence to generate SQL strings for
   * @return              The set of SQL strings
   */
	public String[] getDropSequenceStrings(String sequenceName){
		String[] sequences = { getDropSequenceString(sequenceName) };
		return sequences;
	}

  /**
   * Get the single SQL string to create a sequence
   *
   * Uses default sequence options (START WITH 1 INCREMENT BY 1)
   *
   * @param sequenceName  The sequence to generate a SQL string for
   * @return              The SQL string to create a sequence
   */
	protected String getCreateSequenceString(String sequenceName) {
		return "CREATE SEQUENCE " + sequenceName;                        // by default, is START WITH 1 MAXVALUE 2**63-1
	}

  /**
   * Get the single SQL string to create a sequence
   *
   * Uses non-default sequence options
   *
   * @param sequenceName  The sequence to generate a SQL string for
   * @param initialValue  The initial sequence starting value
   * @param incrementSize The sequence increment step size
   * @return              The SQL string to create a sequence
   */
	protected String getCreateSequenceString(String sequenceName,
			int initialValue,
			int incrementSize) {
		return "CREATE SEQUENCE " + sequenceName + " START WITH " + initialValue + " INCREMENT BY " + incrementSize;
	}

  /**
   * Get the single SQL string to drop a sequence
   *
   * @param sequenceName  The sequence to generate SQL strings for
   * @return              The SQL string to drop a sequence
   */
	protected String getDropSequenceString(String sequenceName){
		return "DROP SEQUENCE " + sequenceName;
	}
}