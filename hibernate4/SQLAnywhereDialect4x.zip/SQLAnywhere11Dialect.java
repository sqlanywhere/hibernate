/**
 * SQL Dialect for SQL Anywhere 11 with ANSI Isolation
 * for the Hibernate 4.x distribution
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 * 
 * Support: http://sqlanywhere-forum.sybase.com/
 *          http://www.sap.com/services-and-support/
 *
 */

package org.hibernate.dialect;

import org.hibernate.cfg.Environment;
import org.hibernate.dialect.function.StandardSQLFunction;
import org.hibernate.dialect.function.VarArgsSQLFunction;
import org.hibernate.type.StandardBasicTypes;

/**
 * @author 		SAP AG or an SAP affiliate company
 * @version 	4.0
 * @since			2009-06-15
 */
public class SQLAnywhere11Dialect extends SQLAnywhere10Dialect {

	static final String DEFAULT_WIDE_BATCH_SIZE = "40";

  /**
   * Constructor to create a SQL Anywhere 11 SQL Dialect
   *
   * Uses standard ANSI Isolation Levels
   */
	public SQLAnywhere11Dialect(){
		super();
		if (SQLAnywhere11Dialect.class.isInstance(this)) {
			registerSA11Keywords();
			registerSA11Functions();
		}
	}

  /**
   * Register SQL Anywhere 11 specific SQL keywords
   */
	private void registerSA11Keywords(){
		registerKeyword( "merge" );
		registerKeyword( "openstring" );
		registerKeyword( "with_cube" );
		registerKeyword( "with_lparen" );
		registerKeyword( "with_rollup" );
	}

  /**
   * Register SQL Anywhere 11 specific SQL system functions
   */
	private void registerSA11Functions(){	
		registerFunction( "regex_substr", new VarArgsSQLFunction( StandardBasicTypes.STRING, "regex_substr(",",",")" ) );
		registerFunction( "read_client_file", new StandardSQLFunction("read_client_file", StandardBasicTypes.BLOB) );
		registerFunction( "write_client_file", new VarArgsSQLFunction( StandardBasicTypes.INTEGER, "write_client_file(",",",")" ) );
	}

	/**
	 * Determine "batch" support for PreparedStatements
	 * <p>
	 * The SQL Anywhere 11.x JDBC driver supports the addBatch() and
	 * executeBatch() methods for a preparedStatement for all update
	 * DML statements (INSERT, UPDATE, DELETE). At this time, however,
	 * the SQL Anywhere server supports ONLY wide INSERT SQL
	 * statements. Wide UPDATE and DELETE statements are supported
	 * from the client, but the server only executes a single UPDATE
	 * or DELETE at a time.
	 */
	protected void setDialectProperties() {
		getDefaultProperties().setProperty( Environment.STATEMENT_BATCH_SIZE, 
				DEFAULT_WIDE_BATCH_SIZE );
	}

	/**
	 * Retrieve the SQL string to provide default column values for INSERT
	 *
	 * SQL Anywhere 11.x supports 'DEFAULT VALUES' to specify all
	 * default columns in a row
	 *
	 * @return              The SQL string to provide default column values in an INSERT
	 */
	public String getNoColumnsInsertString() {
		return "default values";
	}
}
