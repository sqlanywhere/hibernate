/**
 * SQL Dialect for SQL Anywhere 10 with ANSI Isolation
 * for the Hibernate 4.x distribution
 *
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 * 
 * Support: http://sqlanywhere-forum.sybase.com/
 *          http://www.sap.com/services-and-support/
 *
 */

package org.hibernate.dialect;

import java.sql.CallableStatement;
import java.sql.Types;
import java.sql.SQLException;
import java.sql.ResultSet;
import java.util.Map;
import java.util.Iterator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import org.hibernate.Hibernate;
import org.hibernate.HibernateException;
import org.hibernate.LockMode;
import org.hibernate.MappingException;
import org.hibernate.QueryException;
import org.hibernate.sql.CaseFragment;
import org.hibernate.sql.DecodeCaseFragment;
import org.hibernate.sql.JoinFragment;
import org.hibernate.sql.ANSIJoinFragment;
import org.hibernate.sql.CaseFragment;
import org.hibernate.sql.ForUpdateFragment;
import org.hibernate.cfg.Environment;
import org.hibernate.dialect.function.CastFunction;
import org.hibernate.dialect.function.SQLFunction;
import org.hibernate.dialect.function.StandardSQLFunction;
import org.hibernate.dialect.function.NoArgSQLFunction;
import org.hibernate.dialect.function.VarArgsSQLFunction;
import org.hibernate.dialect.function.SQLFunctionTemplate;
import org.hibernate.dialect.function.NvlFunction;
import org.hibernate.dialect.lock.LockingStrategy;
import org.hibernate.dialect.lock.SelectLockingStrategy;
import org.hibernate.id.IdentityGenerator;
import org.hibernate.id.SequenceGenerator;
import org.hibernate.id.TableHiLoGenerator;
import org.hibernate.internal.util.ReflectHelper;
import org.hibernate.internal.util.StringHelper;
import org.hibernate.persister.entity.Lockable;
import org.hibernate.type.StandardBasicTypes;
import org.hibernate.type.Type;

/**
 * @author 		SAP AG or an SAP affiliate company
 * @version 	4.0
 * @since			2008-08-28
 */
public class SQLAnywhere10Dialect extends Dialect {

  /**
   * Constructor to create a SQL Anywhere 10 SQL Dialect
   *
   * Uses standard ANSI Isolation Levels
   */
	public SQLAnywhere10Dialect() {
		super();

		registerDataTypes();
		
		registerFunctions();
		setDialectProperties();
		registerKeywords();

		if (SQLAnywhere10Dialect.class.isInstance(this)) {
			registerSA10Keywords();
		}
	}

  /**
   * Register all valid SQL data type mappings for SQL Anywhere
   */
	protected void registerDataTypes() {
		registerCharacterTypeMappings();
		registerNumericTypeMappings();
		registerDateTimeTypeMappings();
		registerLargeObjectTypeMappings();
	}

  /**
   * Register all valid character data type mappings for SQL Anywhere
   */
	protected void registerCharacterTypeMappings() {
		registerColumnType( Types.CHAR, "char(1)" );
		registerColumnType( Types.VARCHAR, 32767, "varchar($l)" );
		registerColumnType( Types.VARCHAR, "long varchar" );
	}

  /**
   * Register all valid numeric data type mappings for SQL Anywhere
   */
	protected void registerNumericTypeMappings() {
		registerColumnType( Types.BIT, "bit" );               // BIT type is NOT NULL by default
		registerColumnType( Types.BIGINT, "bigint" );
		registerColumnType( Types.SMALLINT, "smallint" );
		registerColumnType( Types.TINYINT, "tinyint" );
		registerColumnType( Types.INTEGER, "integer" );
		registerColumnType( Types.FLOAT, "real" );
		registerColumnType( Types.DOUBLE, "double" );
		registerColumnType( Types.NUMERIC, "numeric($p,$s)" );
		registerColumnType( Types.DECIMAL, "numeric($p,$s)" );
	}

  /**
   * Register all valid date/time data type mappings for SQL Anywhere
   */
	protected void registerDateTimeTypeMappings() {
		registerColumnType( Types.DATE, "date" );
		registerColumnType( Types.TIME, "time" );
		registerColumnType( Types.TIMESTAMP, "timestamp" );
	}

  /**
   * Register all valid binary / LOB data type mappings for SQL Anywhere
   */
	protected void registerLargeObjectTypeMappings() {
		registerColumnType( Types.BINARY, 32767, "varbinary($l)" );
		registerColumnType( Types.BINARY, "long binary" );
		registerColumnType( Types.VARBINARY, 32767, "varbinary($l)" );
		registerColumnType( Types.VARBINARY, "long binary" );		
		registerColumnType( Types.CLOB, "long varchar" );     // org.hibernate.type.ClobType
		registerColumnType( Types.BLOB, "long binary" );      // org.hibernate.type.BlobType
		registerColumnType( Types.LONGVARBINARY, "image" );   // org.hibernate.type.ImageType
	}

  /**
   * Register all SQL system functions for SQL Anywhere for use within Hibernate queries
   */
	protected void registerFunctions() {
		registerMathFunctions();
		registerXMLFunctions();
		registerAggregationFunctions();
		registerBitFunctions();
		registerDateFunctions();
		registerStringFunctions();
		registerSOAPFunctions();
		registerMiscellaneousFunctions();
	}

  /**
   * Register all math SQL system functions for SQL Anywhere
   */
	protected void registerMathFunctions() {
		registerFunction( "abs", new StandardSQLFunction("abs") );
		registerFunction( "acos", new StandardSQLFunction("acos", StandardBasicTypes.DOUBLE) );
		registerFunction( "asin", new StandardSQLFunction("asin", StandardBasicTypes.DOUBLE) );
		registerFunction( "atan", new StandardSQLFunction("atan", StandardBasicTypes.DOUBLE) );
		registerFunction( "atan2", new StandardSQLFunction("atan2", StandardBasicTypes.DOUBLE) );
		registerFunction( "ceiling", new StandardSQLFunction("ceiling", StandardBasicTypes.DOUBLE) );
		registerFunction( "cos", new StandardSQLFunction("cos", StandardBasicTypes.DOUBLE) );
		registerFunction( "cot", new StandardSQLFunction("cot", StandardBasicTypes.DOUBLE) );
		registerFunction( "degrees", new StandardSQLFunction("degrees", StandardBasicTypes.DOUBLE) );
		registerFunction( "exp", new StandardSQLFunction("exp", StandardBasicTypes.DOUBLE) );
		registerFunction( "floor", new StandardSQLFunction("floor", StandardBasicTypes.DOUBLE) );
		registerFunction( "log", new StandardSQLFunction("log", StandardBasicTypes.DOUBLE) );
		registerFunction( "log10", new StandardSQLFunction("log10", StandardBasicTypes.DOUBLE) );
		registerFunction( "mod", new StandardSQLFunction("mod") );
		registerFunction( "pi", new NoArgSQLFunction("pi", StandardBasicTypes.DOUBLE) );
		registerFunction( "power", new StandardSQLFunction("power", StandardBasicTypes.DOUBLE) );
		registerFunction( "radians", new StandardSQLFunction("radians", StandardBasicTypes.DOUBLE) );
		registerFunction( "rand", new StandardSQLFunction("rand", StandardBasicTypes.DOUBLE) );
		registerFunction( "remainder", new StandardSQLFunction("remainder") );
		registerFunction( "round", new StandardSQLFunction("round") );
		registerFunction( "sign", new StandardSQLFunction("sign", StandardBasicTypes.INTEGER) );
		registerFunction( "sin", new StandardSQLFunction("sin", StandardBasicTypes.DOUBLE) );
		registerFunction( "sqrt", new StandardSQLFunction("sqrt", StandardBasicTypes.DOUBLE) );
		registerFunction( "tan", new StandardSQLFunction("tan", StandardBasicTypes.DOUBLE) );
		registerFunction( "truncate", new StandardSQLFunction("truncate") );
	}

  /**
   * Register all XML SQL system functions for SQL Anywhere
   *
   * Note: Only XML scalar functions are supported. 'XMLFOREST' is not supported.
   */
	protected void registerXMLFunctions() {
		registerFunction( "xmlconcat", new VarArgsSQLFunction( StandardBasicTypes.STRING, "xmlconcat(", ",", ")" ) );
		registerFunction( "xmlelement", new VarArgsSQLFunction( StandardBasicTypes.STRING, "xmlelement(", ",", ")" ) );
		registerFunction( "xmlgen", new VarArgsSQLFunction( StandardBasicTypes.STRING, "xmlgen(", ",", ")" ) );
	}

  /**
   * Register all aggregate, linear regression OLAP and window SQL system functions for SQL Anywhere
   */
	protected void registerAggregationFunctions() {
		registerFunction( "covar_pop", new StandardSQLFunction("covar_pop", StandardBasicTypes.DOUBLE) );
		registerFunction( "covar_samp", new StandardSQLFunction("covar_samp", StandardBasicTypes.DOUBLE) );
		registerFunction( "corr", new StandardSQLFunction("corr", StandardBasicTypes.DOUBLE) );
		registerFunction( "first_value", new VarArgsSQLFunction(StandardBasicTypes.DOUBLE, "first_value(", ",", ")" ));
		registerFunction( "grouping", new StandardSQLFunction("grouping", StandardBasicTypes.INTEGER) );
		registerFunction( "last_value", new VarArgsSQLFunction(StandardBasicTypes.DOUBLE, "last_value(", ",", ")" ));
		registerFunction( "list", new VarArgsSQLFunction("list(", ",", ")" ));
		registerFunction( "regr_avgx", new StandardSQLFunction("regr_avgx", StandardBasicTypes.DOUBLE) );
		registerFunction( "regr_avgy", new StandardSQLFunction("regr_avgy", StandardBasicTypes.DOUBLE) );
		registerFunction( "regr_count", new StandardSQLFunction("regr_count", StandardBasicTypes.DOUBLE) );
		registerFunction( "regr_intercept", new StandardSQLFunction("regr_intercept", StandardBasicTypes.DOUBLE) );
		registerFunction( "regr_r2", new StandardSQLFunction("regr_r2", StandardBasicTypes.DOUBLE) );
		registerFunction( "regr_slope", new StandardSQLFunction("regr_slope", StandardBasicTypes.DOUBLE) );
		registerFunction( "regr_sxx", new StandardSQLFunction("regr_sxx", StandardBasicTypes.DOUBLE) );
		registerFunction( "regr_sxy", new StandardSQLFunction("regr_sxy", StandardBasicTypes.DOUBLE) );
		registerFunction( "regr_syy", new StandardSQLFunction("regr_syy", StandardBasicTypes.DOUBLE) );
		registerFunction( "set_bits", new StandardSQLFunction("set_bits") );
		registerFunction( "stddev", new StandardSQLFunction("stddev", StandardBasicTypes.DOUBLE) );
		registerFunction( "stddev_pop", new StandardSQLFunction("stddev_pop", StandardBasicTypes.DOUBLE) );
		registerFunction( "stddev_samp", new StandardSQLFunction("stddev_samp", StandardBasicTypes.DOUBLE) );
		registerFunction( "variance", new StandardSQLFunction("variance", StandardBasicTypes.DOUBLE) );
		registerFunction( "var_pop", new StandardSQLFunction("var_pop", StandardBasicTypes.DOUBLE) );
		registerFunction( "var_samp", new StandardSQLFunction("var_samp", StandardBasicTypes.DOUBLE) );
		registerFunction( "xmlagg", new StandardSQLFunction("xmlagg") );
	}

  /**
   * Register all bit SQL system functions for SQL Anywhere
   */
	protected void registerBitFunctions() {
		registerFunction( "bit_or", new StandardSQLFunction("bit_or") );
		registerFunction( "bit_and", new StandardSQLFunction("bit_and") );
		registerFunction( "bit_xor", new StandardSQLFunction("bit_xor") );
		registerFunction( "bit_length", new StandardSQLFunction("bit_length", StandardBasicTypes.INTEGER) );
		registerFunction( "bit_substr", new StandardSQLFunction("bit_substr") );
		registerFunction( "get_bit", new StandardSQLFunction("get_bit", StandardBasicTypes.BOOLEAN) );
		registerFunction( "set_bit", new VarArgsSQLFunction("set_bit(", ",", ")" ));
	}

  /**
   * Register all date SQL system functions for SQL Anywhere
   */
	protected void registerDateFunctions() {

		registerFunction( "date", new StandardSQLFunction("date", StandardBasicTypes.DATE) );
		registerFunction( "dateadd", new StandardSQLFunction("dateadd", StandardBasicTypes.TIMESTAMP) );
		registerFunction( "datediff", new StandardSQLFunction("datediff", StandardBasicTypes.INTEGER) );
		registerFunction( "dateformat", new StandardSQLFunction("dateformat", StandardBasicTypes.STRING) );
		registerFunction( "datename", new StandardSQLFunction("datename", StandardBasicTypes.STRING) );
		registerFunction( "datepart", new StandardSQLFunction("datepart", StandardBasicTypes.INTEGER) );
		registerFunction( "datetime", new StandardSQLFunction("datetime", StandardBasicTypes.TIMESTAMP) );
		registerFunction( "day", new StandardSQLFunction("day", StandardBasicTypes.INTEGER) );
		registerFunction( "dayname", new StandardSQLFunction("dayname", StandardBasicTypes.STRING) );
		registerFunction( "days", new StandardSQLFunction("days") );
		registerFunction( "dow", new StandardSQLFunction("dow", StandardBasicTypes.INTEGER) );
		registerFunction( "getdate", new StandardSQLFunction("getdate", StandardBasicTypes.TIMESTAMP) );
		registerFunction( "hour", new StandardSQLFunction("hour", StandardBasicTypes.INTEGER) );
		registerFunction( "hours", new StandardSQLFunction("hours") );
		registerFunction( "minute", new StandardSQLFunction("minute", StandardBasicTypes.INTEGER) );
		registerFunction( "minutes", new StandardSQLFunction("minutes") );
		registerFunction( "month", new StandardSQLFunction("month", StandardBasicTypes.INTEGER) );
		registerFunction( "monthname", new StandardSQLFunction("monthname", StandardBasicTypes.STRING) );
		registerFunction( "months", new StandardSQLFunction("months") );
		registerFunction( "now", new NoArgSQLFunction("now", StandardBasicTypes.TIMESTAMP) );
		registerFunction( "quarter", new StandardSQLFunction("quarter", StandardBasicTypes.INTEGER) );
		registerFunction( "second", new StandardSQLFunction("second", StandardBasicTypes.INTEGER) );
		registerFunction( "seconds", new StandardSQLFunction("seconds") );
		registerFunction( "today", new NoArgSQLFunction("now", StandardBasicTypes.DATE) );
		registerFunction( "weeks", new StandardSQLFunction("weeks") );
		registerFunction( "year", new StandardSQLFunction("year", StandardBasicTypes.INTEGER) );
		registerFunction( "years", new StandardSQLFunction("years") );
		registerFunction( "ymd", new StandardSQLFunction("ymd", StandardBasicTypes.DATE) );
		registerFunction( "current_timestamp", new NoArgSQLFunction("getdate", StandardBasicTypes.TIMESTAMP) );
		registerFunction( "current_time", new NoArgSQLFunction("getdate", StandardBasicTypes.TIME) );
		registerFunction( "current_date", new NoArgSQLFunction("getdate", StandardBasicTypes.DATE) );
	}

  /**
   * Register all string SQL system functions for SQL Anywhere
   *
   * Note: substr() semantics depends on the 'ansi_substring' database option
   * 
   * See: http://dcx.sybase.com/index.html#1001/en/dbdaen10/da-dboptions-s-5616536.html
   */
	protected void registerStringFunctions() {
		registerFunction( "ascii", new StandardSQLFunction("ascii", StandardBasicTypes.INTEGER) );
		registerFunction( "byte64_decode", new StandardSQLFunction("byte64_decode", StandardBasicTypes.CLOB) );
		registerFunction( "byte64_encode", new StandardSQLFunction("byte64_encode", StandardBasicTypes.CLOB) );
		registerFunction( "byte_length", new StandardSQLFunction("byte_length", StandardBasicTypes.INTEGER) );
		registerFunction( "byte_substr", new VarArgsSQLFunction( StandardBasicTypes.STRING, "byte_substr(",",",")" ) );
		registerFunction( "char", new StandardSQLFunction("char", StandardBasicTypes.CHARACTER) );
		registerFunction( "charindex", new StandardSQLFunction("charindex", StandardBasicTypes.INTEGER) );
		registerFunction( "char_length", new StandardSQLFunction("char_length", StandardBasicTypes.INTEGER) );
		registerFunction( "compare", new VarArgsSQLFunction( StandardBasicTypes.INTEGER, "compare(",",",")" ) );
		registerFunction( "compress", new VarArgsSQLFunction( StandardBasicTypes.BLOB, "compress(",",",")" ) );
		registerFunction( "concat", new VarArgsSQLFunction( StandardBasicTypes.STRING, "(","+",")" ) );
		registerFunction( "csconvert", new VarArgsSQLFunction( StandardBasicTypes.CLOB, "csconvert(",",",")" ) );
		registerFunction( "decompress", new VarArgsSQLFunction( StandardBasicTypes.BLOB, "decompress(",",",")" ) );
		registerFunction( "decrypt", new VarArgsSQLFunction( StandardBasicTypes.BLOB, "decrypt(",",",")" ) );
		registerFunction( "difference", new StandardSQLFunction("difference", StandardBasicTypes.INTEGER) );
		registerFunction( "encrypt", new VarArgsSQLFunction( StandardBasicTypes.BLOB, "encrypt(",",",")" ) );
		registerFunction( "hash", new VarArgsSQLFunction( StandardBasicTypes.STRING, "hash(",",",")" ) );
		registerFunction( "insertstr", new StandardSQLFunction("insertstr", StandardBasicTypes.STRING) );
		registerFunction( "lcase", new StandardSQLFunction("lcase", StandardBasicTypes.STRING) );
		registerFunction( "left", new StandardSQLFunction("left", StandardBasicTypes.STRING) );
		registerFunction( "length", new StandardSQLFunction("length", StandardBasicTypes.LONG) );
		registerFunction( "locate", new VarArgsSQLFunction( StandardBasicTypes.INTEGER, "locate(",",",")" ) );
		registerFunction( "lower", new StandardSQLFunction("lower", StandardBasicTypes.STRING) );
		registerFunction( "ltrim", new StandardSQLFunction("ltrim", StandardBasicTypes.STRING) );
		registerFunction( "patindex", new StandardSQLFunction("patindex", StandardBasicTypes.INTEGER) );
		registerFunction( "repeat", new StandardSQLFunction("repeat", StandardBasicTypes.STRING) );
		registerFunction( "replace", new StandardSQLFunction("replace", StandardBasicTypes.STRING) );
		registerFunction( "replicate", new StandardSQLFunction("replicate", StandardBasicTypes.STRING) );
		registerFunction( "reverse", new StandardSQLFunction("reverse", StandardBasicTypes.STRING) );
		registerFunction( "right", new StandardSQLFunction("right", StandardBasicTypes.STRING) );
		registerFunction( "rtrim", new StandardSQLFunction("rtrim", StandardBasicTypes.STRING) );
		registerFunction( "similar", new StandardSQLFunction("rtrim", StandardBasicTypes.INTEGER) );
		registerFunction( "sortkey", new VarArgsSQLFunction( StandardBasicTypes.BINARY, "sortkey(",",",")" ) );
		registerFunction( "soundex", new StandardSQLFunction("soundex", StandardBasicTypes.INTEGER) );
		registerFunction( "space", new StandardSQLFunction("space", StandardBasicTypes.STRING) );
		registerFunction( "str", new VarArgsSQLFunction( StandardBasicTypes.STRING, "str(",",",")" ) );
		registerFunction( "string", new VarArgsSQLFunction( StandardBasicTypes.STRING, "string(",",",")" ) );
		registerFunction( "strtouuid", new StandardSQLFunction("strtouuid") );
		registerFunction( "stuff", new StandardSQLFunction("stuff", StandardBasicTypes.STRING) );
		registerFunction( "substr", new VarArgsSQLFunction( StandardBasicTypes.STRING, "substr(",",",")" ) );
		registerFunction( "substring", new VarArgsSQLFunction( StandardBasicTypes.STRING, "substr(",",",")" ) );
		registerFunction( "to_char", new VarArgsSQLFunction( StandardBasicTypes.STRING, "to_char(",",",")" ) );
		registerFunction( "to_nchar", new VarArgsSQLFunction( StandardBasicTypes.STRING, "to_nchar(",",",")" ) );
		registerFunction( "trim", new StandardSQLFunction( "trim", StandardBasicTypes.STRING) );
		registerFunction( "ucase", new StandardSQLFunction("ucase", StandardBasicTypes.STRING) );
		registerFunction( "unicode", new StandardSQLFunction("unicode", StandardBasicTypes.INTEGER) );
		registerFunction( "unistr", new StandardSQLFunction("unistr", StandardBasicTypes.STRING) );
		registerFunction( "upper", new StandardSQLFunction("upper", StandardBasicTypes.STRING) );
		registerFunction( "uuidtostr", new StandardSQLFunction("uuidtostr", StandardBasicTypes.STRING) );
	}

	/**
   * Register all SOAP/HTTP SQL system functions for SQL Anywhere
   */
	protected void registerSOAPFunctions() {
		registerFunction( "html_decode", new StandardSQLFunction("html_decode", StandardBasicTypes.STRING) );
		registerFunction( "html_encode", new StandardSQLFunction("html_encode", StandardBasicTypes.STRING) );
		registerFunction( "http_decode", new StandardSQLFunction("http_decode", StandardBasicTypes.STRING) );
		registerFunction( "http_encode", new StandardSQLFunction("http_encode", StandardBasicTypes.STRING) );
		registerFunction( "http_header", new StandardSQLFunction("http_header", StandardBasicTypes.STRING) );
		registerFunction( "http_variable", new VarArgsSQLFunction( "http_variable(",",",")" ) );
		registerFunction( "next_http_header", new StandardSQLFunction("next_http_header", StandardBasicTypes.STRING) );
		registerFunction( "next_http_variable", new StandardSQLFunction("next_http_variable", StandardBasicTypes.STRING) );
		registerFunction( "next_soap_header", new VarArgsSQLFunction( "next_soap_header(",",",")" ) );
	}

	/**
   * Register all extension SQL system functions for SQL Anywhere
   */
	protected void registerMiscellaneousFunctions() {

		registerFunction( "argn", new VarArgsSQLFunction( "argn(",",",")" ) );
		registerFunction( "coalesce", new VarArgsSQLFunction( "coalesce(",",",")" ) );
		registerFunction( "conflict", new StandardSQLFunction("conflict", StandardBasicTypes.BOOLEAN) );
		registerFunction( "connection_property", new VarArgsSQLFunction( "connection_property(",",",")" ) );
		registerFunction( "connection_extended_property", new VarArgsSQLFunction( "connection_extended_property(",",",")" ) );
		registerFunction( "db_extended_property", new VarArgsSQLFunction( "db_extended_property(",",",")" ) );
		registerFunction( "db_property", new VarArgsSQLFunction( "db_property(",",",")" ) );
		registerFunction( "errormsg", new NoArgSQLFunction("errormsg", StandardBasicTypes.STRING) );
		registerFunction( "estimate", new VarArgsSQLFunction( "estimate(",",",")" ) );
		registerFunction( "estimate_source", new VarArgsSQLFunction( StandardBasicTypes.STRING, "estimate_source(",",",")" ) );
		registerFunction( "experience_estimate", new VarArgsSQLFunction( "experience_estimate(",",",")" ) );
		registerFunction( "explanation", new VarArgsSQLFunction( StandardBasicTypes.STRING, "explanation(",",",")" ) );
		registerFunction( "exprtype", new StandardSQLFunction("exprtype", StandardBasicTypes.STRING) );
		registerFunction( "get_identity", new VarArgsSQLFunction( "get_identity(",",",")" ) );
		registerFunction( "graphical_plan", new VarArgsSQLFunction( StandardBasicTypes.STRING, "graphical_plan(",",",")" ) );
		registerFunction( "greater", new StandardSQLFunction("greater") );
		registerFunction( "identity", new StandardSQLFunction("identity") );
		registerFunction( "ifnull", new VarArgsSQLFunction( "ifnull(",",",")" ) );
		registerFunction( "index_estimate", new VarArgsSQLFunction( "index_estimate(",",",")" ) );
		registerFunction( "isnull", new VarArgsSQLFunction( "isnull(",",",")" ) );
		registerFunction( "lesser", new StandardSQLFunction("lesser") );
		registerFunction( "newid", new NoArgSQLFunction("newid", StandardBasicTypes.STRING) );
		registerFunction( "nullif", new StandardSQLFunction("nullif") );
		registerFunction( "number", new NoArgSQLFunction("number", StandardBasicTypes.INTEGER) );
		registerFunction( "plan", new VarArgsSQLFunction( StandardBasicTypes.STRING, "plan(",",",")" ) );
		registerFunction( "property", new StandardSQLFunction( "property", StandardBasicTypes.STRING ) );
		registerFunction( "property_description", new StandardSQLFunction( "property_description", StandardBasicTypes.STRING ) );
		registerFunction( "property_name", new StandardSQLFunction( "property_name", StandardBasicTypes.STRING ) );
		registerFunction( "property_number", new StandardSQLFunction( "property_number", StandardBasicTypes.INTEGER ) );
		registerFunction( "rewrite", new VarArgsSQLFunction( StandardBasicTypes.STRING, "rewrite(",",",")" ) );
		registerFunction( "row_number", new NoArgSQLFunction("row_number", StandardBasicTypes.INTEGER) );
		registerFunction( "sqldialect", new StandardSQLFunction("sqldialect", StandardBasicTypes.STRING) );
		registerFunction( "sqlflagger", new StandardSQLFunction("sqlflagger", StandardBasicTypes.STRING) );
		registerFunction( "traceback", new NoArgSQLFunction("traceback", StandardBasicTypes.STRING) );
		registerFunction( "transactsql", new NoArgSQLFunction("transactsql", StandardBasicTypes.STRING) );
		registerFunction( "varexists", new StandardSQLFunction("varexists", StandardBasicTypes.INTEGER) );
		registerFunction( "watcomsql", new StandardSQLFunction("watcomsql", StandardBasicTypes.STRING) );
	}

	/**
   * Register all database keywords for SQL Anywhere
   */
	protected void registerKeywords() {
		registerKeyword( "add" );
		registerKeyword( "all" );
		registerKeyword( "alter" );
		registerKeyword( "and" );
		registerKeyword( "any" );
		registerKeyword( "as" );
		registerKeyword( "asc" );
		registerKeyword( "attach" );
		registerKeyword( "backup" );
		registerKeyword( "begin" );
		registerKeyword( "between" );
		registerKeyword( "bigint" );
		registerKeyword( "binary" );
		registerKeyword( "bit" );
		registerKeyword( "bottom" );
		registerKeyword( "break" );
		registerKeyword( "by" );
		registerKeyword( "call" );
		registerKeyword( "capability" );
		registerKeyword( "cascade" );
		registerKeyword( "case" );
		registerKeyword( "cast" );
		registerKeyword( "char" );
		registerKeyword( "char_convert" );
		registerKeyword( "character" );
		registerKeyword( "check" );
		registerKeyword( "checkpoint" );
		registerKeyword( "close" );
		registerKeyword( "comment" );
		registerKeyword( "commit" );
		registerKeyword( "compressed" );
		registerKeyword( "conflict" );
		registerKeyword( "connect" );
		registerKeyword( "constraint" );
		registerKeyword( "contains" );
		registerKeyword( "continue" );
		registerKeyword( "convert" );
		registerKeyword( "create" );
		registerKeyword( "cross" );
		registerKeyword( "cube" );
		registerKeyword( "current" );
		registerKeyword( "current_timestamp" );
		registerKeyword( "current_user" );
		registerKeyword( "cursor" );
		registerKeyword( "date" );
		registerKeyword( "dbspace" );
		registerKeyword( "deallocate" );
		registerKeyword( "dec" );
		registerKeyword( "decimal" );
		registerKeyword( "declare" );
		registerKeyword( "default" );
		registerKeyword( "delete" );
		registerKeyword( "deleting" );
		registerKeyword( "desc" );
		registerKeyword( "detach" );
		registerKeyword( "distinct" );
		registerKeyword( "do" );
		registerKeyword( "double" );
		registerKeyword( "drop" );
		registerKeyword( "dynamic" );
		registerKeyword( "else" );
		registerKeyword( "elseif" );
		registerKeyword( "encrypted" );
		registerKeyword( "end" );
		registerKeyword( "endif" );
		registerKeyword( "escape" );
		registerKeyword( "except" );
		registerKeyword( "exception" );
		registerKeyword( "exec" );
		registerKeyword( "execute" );
		registerKeyword( "existing" );
		registerKeyword( "exists" );
		registerKeyword( "externlogin" );
		registerKeyword( "fetch" );
		registerKeyword( "first" );
		registerKeyword( "float" );
		registerKeyword( "for" );
		registerKeyword( "force" );
		registerKeyword( "foreign" );
		registerKeyword( "forward" );
		registerKeyword( "from" );
		registerKeyword( "full" );
		registerKeyword( "goto" );
		registerKeyword( "grant" );
		registerKeyword( "group" );
		registerKeyword( "having" );
		registerKeyword( "holdlock" );
		registerKeyword( "identified" );
		registerKeyword( "if" );
		registerKeyword( "in" );
		registerKeyword( "index" );
		registerKeyword( "index_lparen" );
		registerKeyword( "inner" );
		registerKeyword( "inout" );
		registerKeyword( "insensitive" );
		registerKeyword( "insert" );
		registerKeyword( "inserting" );
		registerKeyword( "install" );
		registerKeyword( "instead" );
		registerKeyword( "int" );
		registerKeyword( "integer" );
		registerKeyword( "integrated" );
		registerKeyword( "intersect" );
		registerKeyword( "into" );
		registerKeyword( "is" );
		registerKeyword( "isolation" );
		registerKeyword( "join" );
		registerKeyword( "kerberos" );
		registerKeyword( "key" );
		registerKeyword( "lateral" );
		registerKeyword( "left" );
		registerKeyword( "like" );
		registerKeyword( "lock" );
		registerKeyword( "login" );
		registerKeyword( "long" );
		registerKeyword( "match" );
		registerKeyword( "membership" );
		registerKeyword( "message" );
		registerKeyword( "mode" );
		registerKeyword( "modify" );
		registerKeyword( "natural" );
		registerKeyword( "nchar" );
		registerKeyword( "new" );
		registerKeyword( "no" );
		registerKeyword( "noholdlock" );
		registerKeyword( "not" );
		registerKeyword( "notify" );
		registerKeyword( "null" );
		registerKeyword( "numeric" );
		registerKeyword( "nvarchar" );
		registerKeyword( "of" );
		registerKeyword( "off" );
		registerKeyword( "on" );
		registerKeyword( "open" );
		registerKeyword( "option" );
		registerKeyword( "options" );
		registerKeyword( "or" );
		registerKeyword( "order" );
		registerKeyword( "others" );
		registerKeyword( "out" );
		registerKeyword( "outer" );
		registerKeyword( "over" );
		registerKeyword( "passthrough" );
		registerKeyword( "precision" );
		registerKeyword( "prepare" );
		registerKeyword( "primary" );
		registerKeyword( "print" );
		registerKeyword( "privileges" );
		registerKeyword( "proc" );
		registerKeyword( "procedure" );
		registerKeyword( "publication" );
		registerKeyword( "raiserror" );
		registerKeyword( "readtext" );
		registerKeyword( "real" );
		registerKeyword( "reference" );
		registerKeyword( "references" );
		registerKeyword( "refresh" );
		registerKeyword( "release" );
		registerKeyword( "remote" );
		registerKeyword( "remove" );
		registerKeyword( "rename" );
		registerKeyword( "reorganize" );
		registerKeyword( "resource" );
		registerKeyword( "restore" );
		registerKeyword( "restrict" );
		registerKeyword( "return" );
		registerKeyword( "revoke" );
		registerKeyword( "right" );
		registerKeyword( "rollback" );
		registerKeyword( "rollup" );
		registerKeyword( "save" );
		registerKeyword( "savepoint" );
		registerKeyword( "scroll" );
		registerKeyword( "select" );
		registerKeyword( "sensitive" );
		registerKeyword( "session" );
		registerKeyword( "set" );
		registerKeyword( "setuser" );
		registerKeyword( "share" );
		registerKeyword( "smallint" );
		registerKeyword( "some" );
		registerKeyword( "sqlcode" );
		registerKeyword( "sqlstate" );
		registerKeyword( "start" );
		registerKeyword( "stop" );
		registerKeyword( "subtrans" );
		registerKeyword( "subtransaction" );
		registerKeyword( "synchronize" );
		registerKeyword( "syntax_error" );
		registerKeyword( "table" );
		registerKeyword( "temporary" );
		registerKeyword( "then" );
		registerKeyword( "time" );
		registerKeyword( "timestamp" );
		registerKeyword( "tinyint" );
		registerKeyword( "to" );
		registerKeyword( "top" );
		registerKeyword( "tran" );
		registerKeyword( "trigger" );
		registerKeyword( "truncate" );
		registerKeyword( "tsequal" );
		registerKeyword( "unbounded" );
		registerKeyword( "union" );
		registerKeyword( "unique" );
		registerKeyword( "uniqueidentifier" );
		registerKeyword( "unknown" );
		registerKeyword( "unsigned" );
		registerKeyword( "update" );
		registerKeyword( "updating" );
		registerKeyword( "user" );
		registerKeyword( "using" );
		registerKeyword( "validate" );
		registerKeyword( "values" );
		registerKeyword( "varbinary" );
		registerKeyword( "varbit" );
		registerKeyword( "varchar" );
		registerKeyword( "variable" );
		registerKeyword( "varying" );
		registerKeyword( "view" );
		registerKeyword( "wait" );
		registerKeyword( "waitfor" );
		registerKeyword( "when" );
		registerKeyword( "where" );
		registerKeyword( "while" );
		registerKeyword( "window" );
		registerKeyword( "with" );
		registerKeyword( "within" );
		registerKeyword( "work" );
		registerKeyword( "writetext" );
		registerKeyword( "xml" );
	}

	/**
   * Register all SQL Anywhere 10 database keywords for SQL Anywhere
   */
	private void registerSA10Keywords(){
		registerKeyword( "iq" );
		registerKeyword( "with_cube" );
		registerKeyword( "with_lparen" );
		registerKeyword( "with_rollup" );
	}

	/**
	 * Determine "batch" support for PreparedStatements
	 *
	 * SQL Anywhere 10 supports the addBatch() and executeBatch() methods
	 * for a preparedStatement, but only for INSERT SQL statements;
	 * the JDBC driver will raise an exception if this is attempted
	 * for UPDATE or DELETE statements, or other types of SQL
	 * statements. If enabled, Hibernate will attempt to batch any
	 * type of statement; consequently, we must disable batching
	 * support in its entirety. This means that wide inserts cannot be
	 * utilized by a Hibernate application unless the application
	 * constructs its own wide insert through a JDBC call.
	 **/

	protected void setDialectProperties() {
		getDefaultProperties().setProperty( Environment.STATEMENT_BATCH_SIZE, NO_BATCH );
	}

	/**
   * Check Identity Support
   *
   * SQL Anywhere supports 'SELECT @@IDENTITY' to retrieve the previously generated
   * autoincrement key
   * 
   * @return     Whether the Dialect supports Identity columns
   */
  public boolean supportsIdentityColumns() {
		return true;
	}

	/**
   * Generate a SQL String to retreive the previous identity
   * 
   * @return     SQL string to SELECT the previous identity
   */
	public String getIdentitySelectString() {
		return "select @@identity";
	}

	/** 
	 * Generate a SQL string to insert an identity column into schema
   *
   * @return     SQL string to generate an identity column
   */
	public String getIdentityColumnString() {
		return "not null default autoincrement"; 
	}

	/** 
	 * Determine if INSERTs can also be used with identities
	 *
   * @return     true if INSERT supports identities, false otherwise
   */
	public boolean supportsInsertSelectIdentity() {
		return true;
	}

	/** 
	 * Determine the SQL string to retrieve the identity from the last INSERT
	 *
	 * @return     INSERT SQL with appended identity SELECT
	 */
	public String appendIdentitySelectToInsert(String insertSQL) {
		return insertSQL + "\nselect @@identity";
	}

	/** 
	 * Determine the SQL string to generate a GUID/UUID
	 *
	 * @return     SELECT SQL to generate a GUID/UUID from the database
	 */
	public String getSelectGUIDString() {
		return "select newid()";
	}

	/**
	 * Determine record limiting support.
	 *
	 * SQL Anywhere 10 and up supports 'TOP N' and 'START AT' clauses.
	 *
	 * 'LIMIT' is not specifically used in this dialect.
	 *
	 * @return    True if the dialect supports limiting select results
	 */
	public boolean supportsLimit() {
		return true;
	}

	/**
	 * Determine whether record limiting supports an offset argument
	 *
	 * SQL Anywhere 10 and up supports the 'START AT' clause.
	 */
	public boolean supportsLimitOffset() {
		return true;
	}

	/**
	 * Determine whether record limiting supports an offset argument
	 * Expects to use parameterized SQL queries
	 *
	 * SQL Anywhere 10 and up supports the 'START AT' clause.
	 */
	public boolean supportsVariableLimit() {
		return true;
	}

	/**
	 * Determine the argument order for binding arguments for limits
	 *
	 * SQL Anywhere syntax is SELECT TOP n START AT m
	 *
	 * @return    Specifies if 'limit' is first
	 */
	public boolean bindLimitParametersInReverseOrder() {
		return true;
	}

	/**
	 * Determine the runtime order for binding arguments for limits
	 *
	 * @return   If the LIMIT clauses should be bound first
   */
	public boolean bindLimitParametersFirst() {
		return true;
	}

	/**
	 * Determine the string index after the 'select' portion in a SQL string
	 *
	 * @param    SQL string to be analyzed
	 * @return   String index following the 'select' or 'select distinct' text
   */
	static int getAfterSelectInsertPoint(String sql) {
		int selectIndex = sql.toLowerCase().indexOf( "select" );
		final int selectDistinctIndex = sql.toLowerCase().indexOf( "select distinct" );
		return selectIndex + ( selectDistinctIndex == selectIndex ? 15 : 6 );
	}

	/**
	 * Insert parameterized limit string into a SQL SELECT string
	 *
	 * @param    The original SQL SELECT string that does not have a limit
	 * @param    Specify if an offset clause should be added or not
	 * @return   Parameterized SQL string that contains a limit
   */
	public String getLimitString( String sql, boolean hasOffset ) {
		StringBuffer buf = new StringBuffer( sql.length() + 28 )
		.append( sql );
		if( hasOffset ) {
			buf.insert( getAfterSelectInsertPoint( sql ), 
					" top ? start at ? " );
		} else {
			buf.insert( getAfterSelectInsertPoint( sql ), 
					" top ? " );
		}
		return buf.toString();
	}

	/**
	 * Generate a parameterized SQL string that contains a limit
	 *
	 * @throws UnsupportedOperationException    If offset < 0 or limit <= 0
	 *
	 * @param    The original SQL string that does not have a limit
	 * @param    Offset to start limit from (offset >= 0)
	 * @param    Number of results to limit to (limit > 0)
	 *
	 * @return   Parameterized SQL string that contains a limit
   */
	public String getLimitString( String querySelect, int offset, int limit ) 
			throws UnsupportedOperationException {
		if ( offset < 0 ) {
			throw new UnsupportedOperationException( "negative FirstResult (SQL offset) is not supported" );
		}
		if ( limit <= 0 ) {
			throw new UnsupportedOperationException( "negative or zero MaxResults (SQL limit) is not supported" );
		}
		return getLimitString(querySelect, offset > 0 );
	}

	/**
   * Generate an SQL SELECT component string, based on intended lock behaviour
	 *
	 * SQL Anywhere 10 supports READ, WRITE, and INTENT row
	 * locks. INTENT locks are sufficient to ensure that other
	 * concurrent connections cannot modify a row (though other
	 * connections can still read that row). SQL Anywhere also
	 * supports 3 modes of snapshot isolation (multi-version
	 * concurrency control (MVCC). <p/>
	 *
	 * SQL Anywhere's <tt>FOR UPDATE</tt> clause supports 
	 *     <tt>FOR UPDATE BY [ LOCK | VALUES ]</tt>
	 *     <tt>FOR UPDATE OF ( COLUMN LIST )</tt>
	 *
	 * though they cannot be specified at the same time. <tt>BY LOCK</tt> is
	 * the syntax that acquires INTENT locks.  FOR UPDATE BY VALUES
	 * forces the use of the KEYSET cursor, which returns a warning to
	 * the application when a row in the cursor has been subsequently
	 * modified by another connection, and an error if the row has
	 * been deleted. <p/>
	 *
	 * SQL Anywhere does not support the <tt>FOR UPDATE NOWAIT</tt> syntax of
	 * Oracle on a statement-by-statement basis.  However, the
	 * identical functionality is provided by setting the connection
	 * option <tt>BLOCKING</tt> to "OFF", or setting an appropriate timeout
	 * period through the connection option <tt>BLOCKING_TIMEOUT</tt>.
	 *
	 **/
	public String getForUpdateString( LockMode lockMode ) {
		if( lockMode == LockMode.READ ) {
			return getForReadOnlyString();
		} else if( lockMode == LockMode.UPGRADE ) {
			return getForUpdateByLockString();
		} else if( lockMode == LockMode.UPGRADE_NOWAIT ) {
			return getForUpdateNowaitString();
		} else if( lockMode == LockMode.FORCE ) {
			return getForUpdateNowaitString();
		} else {
			return "";
		}
	}
	
	/**
	 * Determine if <tt>FOR UPDATE OF</tt> syntax is supported
	 *
	 * @return True if the database supports <tt>FOR UPDATE OF</tt> syntax
   *
	 */
	public boolean forUpdateOfColumns() {
		return true;
	}

	/**
	 * Determine if this dialect supports <tt>FOR UPDATE</tt> in conjunction with
	 * outer joined rows?
	 *
	 * @return True if outer joined rows can be locked via <tt>FOR UPDATE</tt>
	 */
	public boolean supportsOuterJoinForUpdate() {
		return true;
	}

	/**
	 * Generate a SQL string component for read-only queries
	 *
	 * Forces the condition that this query is read-only. In SQL Anywhere, this
	 * ensures that certain query rewrite optimizations (such as join elimination)
	 * can be used.
	 *
	 * @return SQL string component that specifies read-only queries
   */
	public String getForReadOnlyString() {
		return " for read only";
	}

	/**
	 * Generate a SQL string component for locked, updatable queries
	 *
	 * In SQL Anywhere, this acquires intent locks on the rows.
	 *
	 * @return SQL string component that specifies rows to lock for updates
	 */
	public String getForUpdateByLockString() {
		return " for update by lock";
	}

	/**
	 * Generate a SQL string component for non-waiting updatable queries
	 *
	 * In SQL Anywhere, this acquires intent locks on the rows.
	 *
	 * @return SQL string component that specifies rows to lock for updates
	 */
	public String getForUpdateNoWaitString() {
		return getForUpdateByLockString();
	}

	/**
	 * Generate a SQL string component for updating only specific columns
	 *
	 * @return SQL string component to specify which columns are updatable
	 */
	public String getForUpdateString(String aliases) {
		return " for update of " + aliases;
	}

	/**
	 * Specify if writers will block readers at isolation 1 or greater
	 *
	 * By default, SQL Anywhere uses ANSI isolation levels. If you wish
	 * to use snapshot isolation, see 'SQLAnywhere10DialectSnapTran' and the
	 * README file
	 *
	 * @return True if writers can block readers at isolation 1 or greater
	 */
	public boolean doesReadCommittedCauseWritersToBlockReaders() {
		return true;
	}

	/**
	 * Specify if readers can block writers at isolation 2 or greater
	 *
	 * By default, SQL Anywhere uses ANSI isolation levels. If you wish
	 * to use snapshot isolation, see 'SQLAnywhere10DialectSnapTran' and the
	 * README file
	 *
	 * @return True if readers can block writers at isolation 2 or greater
	 */
	public boolean doesRepeatableReadCauseReadersToBlockWriters() {
		return true;
	}

	/**
	 * Generate a SQL string component to lock a table with the intended lock mode
	 *
	 * @param    Intended lock mode for the table
	 * @param    The table name to lock
	 * @return   SQL string component to lock a table during SELECT
	 */
	public String appendLockHint(LockMode mode, String tableName) {
		if ( mode.greaterThan( LockMode.READ ) ) {
			return tableName + " with( updlock )"; // Set an INTENT row lock
		} else {
			return tableName;
		}
	}

  /**
   * Generate a SQL string with locking hints, based on the intended locking behaviour 
   * and table names being used
   *
   * In SQL Anywhere, table hints using WITH do *NOT* cascade into base table(s)
   * if the hint is applied to a view. FOR UPDATE BY LOCK in the SELECT clause
   * is strongly preferred.
   *
   * @param     The original SQL string
   * @param     The set of desired lock modes
   * @param     The set of table names
   * @return    The SQL string with lock hints appended to table names
   */
	public String applyLocksToSql(String sql, Map aliasedLockModes, Map keyColumnNames) {
		Iterator itr = aliasedLockModes.entrySet().iterator();
		StringBuffer buffer = new StringBuffer( sql );
		int correction = 0;
		while( itr.hasNext() ) {
			final Map.Entry entry = ( Map.Entry ) itr.next();
			final LockMode lockMode = ( LockMode ) entry.getValue();
			if( lockMode.greaterThan( LockMode.READ ) ) {
				final String alias = ( String ) entry.getKey();
				int start = -1, end = -1;
				if( sql.endsWith( " " + alias ) ) {
					start = ( sql.length() - alias.length() ) + correction;
					end = start + alias.length();
				} else {
					int position = sql.indexOf( " " + alias + " " );
					if( position <= -1 ) {
						position = sql.indexOf( " " + alias + "," );
					}
					if( position > -1 ) {
						start = position + correction + 1;
						end = start + alias.length();
					}
				}

				if( start > -1 ) {
					final String lockHint = appendLockHint( lockMode, alias );
					buffer.replace( start, end, lockHint );
					correction += ( lockHint.length() - alias.length() );
				}
			}
		}
		return buffer.toString();
	}

  /**
   * Specify whether the database can generate the current time
   *
   * @return  True if the database can select the current time
   */
	public boolean supportsCurrentTimestampSelection() {
		return true;
	}

  /**
   * Return the SQL function that maps to the 'current timestamp' function
   *
   * @return  The function mapping name for the 'current timestamp' function
   */

	public String getCurrentTimestampSQLFunctionName() {
		return "getdate";
	}

  /**
   * Return whether the 'current timestamp' function can be directly called
   *
   * @return  True if the function does not require a 'SELECT'
   */
	public boolean isCurrentTimestampSelectStringCallable() {
		return false;
	}

  /**
   * Return the SELECT string for the 'current timestamp'
   *
   * @return  The SQL string to select the 'current timestamp'
   */
	public String getCurrentTimestampSelectString() {
		return "select getdate()";
	}

	/**
   * Return the 'close-quote' character to use for identifiers
	 *
	 * Quoted identifiers are controlled through the QUOTED_IDENTIFIER connection option.
	 *
	 * @return  The 'close-quote' character
	 **/
	public char closeQuote() {
		return '"';
	}

	/**
   * Return the 'open-quote' character to use for identifiers
	 *
	 * Quoted identifiers are controlled through the QUOTED_IDENTIFIER connection option.
	 *
	 * @return  The 'open-quote' character
	 **/
	public char openQuote() {
		return '"';
	}

  /**
   * Return whether the database supports an empty IN list: "IN()"
	 *
	 * @return  True if the database supports an empty IN list
	 **/
	public boolean supportsEmptyInList() {
		return false;
	}

  /**
	 * Specify if this dialect supports asking the result set its positioning
	 * information on forward only cursors.  Specifically, in the case of
	 * scrolling fetches, Hibernate needs to use
	 * {@link java.sql.ResultSet#isAfterLast} and
	 * {@link java.sql.ResultSet#isBeforeFirst}.
	 * <p/>
	 *
	 * @return True if methods like {@link java.sql.ResultSet#isAfterLast} and
	 * {@link java.sql.ResultSet#isBeforeFirst} are supported for forward
	 * only cursors; false otherwise.
	 */
	public boolean supportsResultSetPositionQueryMethodsOnForwardOnlyCursor() {
		return false;
	}
  
  /**
	 * Specify whether the dialect support an exists statement in the select clause
	 *
	 * @return True if exists checks are allowed in the select clause; false otherwise.
	 */
	public boolean supportsExistsInSelect() {
		return false;
	}

	/** 
	 * Specify case-sensitivity for text comparisons
	 *
	 * By default, the SQL Anywhere dbinit utility creates a
	 * case-insensitive database for the CHAR collation.  This can
	 * be changed through the use of the -c command line switch on
	 * dbinit, and the setting may differ for the NCHAR collation
	 * for national character sets.  Whether or not a database
	 * supports case-sensitive comparisons can be determined via
	 * the <tt>DB_EXTENDED_PROPERTY()</tt> function, for example:<p />
	 *
	 * <tt>SELECT DB_EXTENDED_PROPERTY( 'Collation', 'CaseSensitivity');</tt>
	 *
	 * Recompile the class if you are using a case-sensitive database
	 */ 
	public boolean areStringComparisonsCaseInsensitive() {
		// return false;
		return true;
	}

	/**
	 * Specify if constraints need to be dropped before dropping tables
	 *
	 * @return True if constraints must be dropped prior to dropping
	 * the table; false otherwise.
	 */
	public boolean dropConstraints() {
		return false;
	}

	/**
	 * Generate a SQL string component to add a column to a schema
	 *
	 * @return The SQL string component to add a column in 'ALTER TABLE'
	 */
	public String getAddColumnString() {
		return "add ";
	}

	/**
	 * Generate a SQL keyword to specify NULL values
	 *
	 * @return The SQL keyword to specify NULL values
	 */
	public String getNullColumnString() {
		return " null";
	}

	/**
	 * Specify if the dialect is required to explicitly specify indexes
	 *
	 * @return True if it's required to specify index names; false othrwise
	 */
	public boolean qualifyIndexName() {
		return false;
	}

	/**
	 * Generate the SQL string component to drop foreign keys
	 *
	 * @return SQL string component to drop foreign keys in 'ALTER TABLE'
	 */
	public String getDropForeignKeyString() {
		return " drop foreign key ";
	}

	/**
	 * Determine whether the dialect supports comments on objects
	 *
	 * SQL Anywhere does support the 'COMMENT ON' syntax for creating comments
	 * however it does not seem that Hibernate can currently support JPA
	 * comments - see HHH-4369
	 * 
	 * @return True if this dialect supports comments; false otherwise
	 */
	public boolean supportsCommentOn() {
		return false;
	}

	/**
	 * Generate a SQL string component for default column values
	 * 
	 * SQL Anywhere 10 only supports "VALUES (DEFAULT)", not
	 * the ANSI standard "DEFAULT VALUES". This latter syntax is
	 * supported in the SQL Anywhere 11.0.1 release.  In SQL Anywhere 10,
	 * "VALUES (DEFAULT)" works only for a single-column table.
	 *
	 * @return the SQL string component to specify default column values
	 **/
	public String getNoColumnsInsertString() {
		return "values (default)";
	}

  /**
   * Determine whether this dialect supports temporary tables
   *
   * @return True if the database supports temporary tables; false otherwise
   */
	public boolean supportsTemporaryTables() {
		return true;
	}

  /** 
   * Generate a SQL string prefix to generate a temporary table
   *
   * In SQL Anywhere, the syntax:
   *
   * <tt>DECLARE LOCAL TEMPORARY TABLE ...</tt>
   *
	 * can also be used, which creates a temporary table with procedure scope, 
	 * which may be important for stored procedures. For Java clients, this is
	 * less important, though it is possible to create temporary tables within
	 * a Hibernate-built Java stored procedure.
	 *
	 * @return A SQL string prefix to generate a temporary table
   */
	public String getCreateTemporaryTableString() {
		return "create local temporary table ";
	}

  /** 
   * Generate a SQL string suffix to generate a temporary table
   *
   * This assumes that temporary table rows should be preserved across COMMITs.
	 *
	 * @return A SQL string suffix to generate a temporary table
   */
	public String getCreateTemporaryTablePostfix() {
		return " on commit preserve rows ";
	}

  /** 
   * Specify whether temporary table creations cause a COMMIT implicitly
   *
   * SQL Anywhere 10 does not perform a COMMIT upon creation of
	 * a temporary table.  However, it does perform an implicit
	 * COMMIT when creating an index over a temporary table, or
	 * upon ALTERing the definition of temporary table.
	 *
	 * @return null to check the JDBC metadata from the JDBC driver,
	 *         true if a COMMIT is a side-effect, false otherwise.
   */
	public Boolean performTemporaryTableDDLInIsolation() {
		return null;
	}

	/**
	 * Registers an OUT parameter which will be returning a
	 * {@link java.sql.ResultSet}.
	 *
	 * SQL Anywhere just returns automatically here
	 *
	 * @param statement The callable statement.
	 * @param position The bind position at which to register the OUT parameter
	 * @return The number of (contiguous) bind positions used
	 * @throws SQLException Indicates problems registering the OUT parameter
	 */
	public int registerResultSetOutParameter( CallableStatement statement, int col ) throws SQLException {
		return col;
	}
	
	/**
	 * Given a callable statement previously processed by {@link #registerResultSetOutParameter},
	 * extract the {@link java.sql.ResultSet} from the OUT parameter.
	 *
	 * @param statement The callable statement.
	 * @return The extracted result set.
	 * @throws SQLException Indicates problems extracting the result set.
	 */
	public ResultSet getResultSet( CallableStatement ps ) throws SQLException {
		boolean isResultSet = ps.execute();
		// This assumes you will want to ignore any update counts
		while( !isResultSet && ps.getUpdateCount() != -1 ) {
			isResultSet = ps.getMoreResults();
		}
		// You may still have other ResultSets or update counts left to process here
		// but you can't do it now or the ResultSet you just got will be closed
		return ps.getResultSet();
	}

	/**
	 * Does this dialect support UNION ALL, which is generally a faster
	 * variant of UNION?
	 *
	 * @return True if UNION ALL is supported; false otherwise.
	 */
	public boolean supportsUnionAll() {
		return true;
	}

	/**
	 * Specify LOB merging support
	 *
	 * SQL Anywhere JDBC does not support Blob.setBinaryStream(), nor
	 * Connection.createBlob(), so a 'NEW_LOCATOR_LOB_MERGE_STRATEGY',
	 * via a NonContextualLobCreator is used for SAJDBC.<p/>
	 *
	 * 'NEW_LOCATOR_LOB_MERGE_STRATEGY' with a ContextualLobCreator is
	 * used for jConnect 7.
	 */
	public LobMergeStrategy getLobMergeStrategy() {
		return NEW_LOCATOR_LOB_MERGE_STRATEGY;
	}
}
