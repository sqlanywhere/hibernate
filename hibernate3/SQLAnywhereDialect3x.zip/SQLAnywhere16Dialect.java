/**
 * SQL Dialect for SAP Sybase SQL Anywhere 12 with ANSI Isolation
 * for the Hibernate 3.2.2+, 3.5.x, 3.6.x distribution
 * 
 * This library is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 2.1 of the License, or (at your option) any later version.
 * 
 * This library is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 * 
 * You should have received a copy of the GNU Lesser General Public
 * License along with this library; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 * 
 * Support: http://sqlanywhere-forum.sybase.com/
 *          http://www.sap.com/services-and-support/
 *
 */

package org.hibernate.dialect;

import org.hibernate.Hibernate;
import org.hibernate.cfg.Environment;
import org.hibernate.dialect.function.StandardSQLFunction;
import org.hibernate.dialect.function.VarArgsSQLFunction;

/**
 * @author 		SAP AG or an SAP affiliate company
 * @version 	3.1
 * @since			2013-01-22
 */
public class SQLAnywhere16Dialect extends SQLAnywhere12Dialect {

  /**
   * Constructor to create a SQL Anywhere 16 SQL Dialect
   *
   * Uses standard ANSI Isolation Levels
   */
	public SQLAnywhere16Dialect(){
		super();
		if (SQLAnywhere16Dialect.class.isInstance(this)) {
			registerSA16Keywords();
			registerSA16Functions();
		}
	}

  /**
   * Register SQL Anywhere 16 specific SQL keywords
   *
   * Note that this function may need to be changed
   * if 'limit' is registered as a keyword, using 'reserved_keywords'
   *
   * See the SQLAnywhereDialect README for more details
   */
	private void registerSA16Keywords(){
		//registerKeyword( "limit" );

    registerKeyword( "array" );
    registerKeyword( "json" );
		registerKeyword( "merge" );
		registerKeyword( "openstring" );
		registerKeyword( "openxml" );
		registerKeyword( "row" );
		registerKeyword( "rowtype" );
		registerKeyword( "treat" );
		registerKeyword( "unnest" );
		registerKeyword( "varray" );
	}

  /**
   * Register SQL Anywhere 16 specific SQL system functions
   */
	private void registerSA16Functions(){
		// SA11 functions
		registerFunction( "regex_substr", new VarArgsSQLFunction( Hibernate.STRING, "regex_substr(",",",")" ) );
		registerFunction( "read_client_file", new StandardSQLFunction("read_client_file", Hibernate.BLOB) );
		registerFunction( "write_client_file", new VarArgsSQLFunction( Hibernate.INTEGER, "write_client_file(",",",")" ) );
		
		// SA12 functions
		registerFunction( "http_response_header", new StandardSQLFunction("http_response_header", Hibernate.STRING) );
		registerFunction( "next_http_response_header", new StandardSQLFunction("next_http_response_header", Hibernate.STRING) );
		registerFunction( "isencrypted", new VarArgsSQLFunction( Hibernate.STRING, "isencrypted(",",",")" ) );
		
		// SA16 functions
		registerFunction( "bintohex", new StandardSQLFunction("bintohex", Hibernate.BINARY) );
		registerFunction( "hextobin", new StandardSQLFunction("hextobin", Hibernate.STRING) );
	}
}